#!/usr/bin/env python3
# Copyright (c) Meta Platforms, Inc. and affiliates.
#
# This source code is licensed under the MIT license found in the
# LICENSE file in the root directory of this source tree.

"""
3-Objective Electrospun Oil Sorbent optimization problem

References

.. [Wang2020]
    B. Wang, J. Cai, C. Liu, J. Yang, X. Ding. Harnessing a Novel Machine-Learning-Assisted Evolutionary Algorithm to Co-optimize Three Characteristics of an Electrospun Oil Sorbent. ACS Applied Materials & Interfaces, 2020.
"""
from typing import List, Optional

import numpy as np
import torch
from botorch.utils.torch import BufferDict
from torch import Tensor

from discrete_mixed_bo.problems.base import DiscreteTestProblem

class CrewOpt(DiscreteTestProblem):
    
    _discrete_values = {
        "V1": [1, 2, 3, 4, 5],
        "V2": [1, 2, 3, 4, 5],
    }
    
    _bounds = [
        (0, 4),  # 5 ordinal values
        (0, 4),  # 5 ordinal values
    ]
    dim = 2
    
    def __init__(
        self,
        # noise_std: Optional[float] = None,
        negate: bool = False,
        integer_indices: Optional[List[int]] = None,
    ) -> None:
        super().__init__(
            negate=negate, integer_indices=list(range(2))
        )
        
        self._setup(integer_indices=list(range(2)))
        self.discrete_values = BufferDict()
        for k, v in self._discrete_values.items():
            self.discrete_values[k] = torch.tensor(v, dtype=torch.float)
            # self.discrete_values[k] /= self.discrete_values[k].max()
    
    def evaluate_true(self, X: Tensor) -> Tensor:

        X_split = list(torch.split(X, 1, -1))
        X_split_new = []
        # print("X_split", X_split)
        # remap from integer space to proper space
        for i, V_i in enumerate(X_split):
            # print("test:", f"V{X_split[i][0]}")
            # print("evaluate true: i, V_i", i, V_i)
            name = f"V{i+1}"
            # print("evaluate true: name", name)
            # print(self.discrete_values)
            if name in self.discrete_values:
                X_split[i] = self.discrete_values[name][V_i.view(-1).long()].view(
                    V_i.shape
                )
                # print(i)
                # print("Evaluate true: X_split", X_split[i])
        # print("test1")
        # V1, V2 = X_split  
        # print(X_split)
        # print("test1")
        result = self.get_value(X_split)
        return result
    
    def get_value(self, X_split):
        
        # print("get value: X_split",X_split)
        
        # print(X_split)
        value = {
            (1, 1): -16.66,
            (1, 2): -72.54,
            (1, 3): -119.23,
            (1, 4): -166.19,
            (1, 5): -169.59,
            (2, 1): 439.88,
            (2, 2): 479.01,
            (2, 3): 451.86,
            (2, 4): 400.64,
            (2, 5): 352.69,
            (3, 1): 528.16,
            (3, 2): 616.54,
            (3, 3): 616.04,
            (3, 4): 577.81,
            (3, 5): 518.76,
            (4, 1): 533.98,
            (4, 2): 634.72,
            (4, 3): 639.95,
            (4, 4): 619.94,
            (4, 5): 566.78,
            (5, 1): 520.55,
            (5, 2): 638.85,
            (5, 3): 646.10,
            (5, 4): 607.42,
            (5, 5): 557.74,
        }
        
        # print("xitem",X_split)
        result = []
        combined_list = []
        for x1, x2 in zip(X_split[0], X_split[1]):
            combined_list.append((x1, x2))

        for xs in combined_list:
            key = tuple(int(x.item()) for x in xs)
            print("key", key)
            if key in value:
                result.append(torch.tensor(-value[key], dtype=torch.float))
        result = torch.tensor(result)
        result = result.to(torch.float64)
        # for i in range(len(X_split[0])):
        #     # print("get value: xs:", xs)
        #     Xs[i] = torch.tensor([int(X_split[0][i]), int(X_split[1][i])])
        #     print("get value: Xs[i]: ", Xs[i])
        # key = tuple(i, j)
        # print("key",key)
        # if key in value:
        #     result.append(torch.tensor(-value[key],dtype=torch.float))
        
        # result = -torch.tensor([value.get(tuple(xs), 0) for xs in X_split])
        # #result = -torch.tensor([value.get(tuple(x.item() for x in xs), "case not found") for xs in X_split])
        # result = -torch.tensor([value.get(tuple(xs)) for xs in X_split])
        #print("result", result)
        return result
