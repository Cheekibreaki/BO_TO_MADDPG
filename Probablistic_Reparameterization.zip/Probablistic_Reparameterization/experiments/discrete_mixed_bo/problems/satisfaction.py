from typing import List, Optional
import json
import os
import numpy as np
import torch
from botorch.utils.torch import BufferDict
from torch import Tensor
from itertools import product
import random
import subprocess
from discrete_mixed_bo.problems.base import DiscreteTestProblem
random.seed(2609)


interpreter_path = "C:/Users/david/PycharmProjects/MADDPG/venv/Scripts/python.exe"

base_config_path = "C:/Users/david/PycharmProjects/BO_to_MADDPG/base_config_map5_1.yaml"
test_run_config_path = "C:/Users/david/PycharmProjects/MADDPG/assets/BO_TO_MADDPG"
exploration_initializer = "C:/Users/david/PycharmProjects/BO_to_MADDPG/exploration_initializer.py"


class Satisfaction(DiscreteTestProblem):

    _discrete_values = {
        "V1": [0, 1, 2, 3],
        "V2": [0, 1, 2, 3],
        "V3": [0, 1, 2, 3],
        "V4": [0, 1, 2, 3],
    }

    _bounds = [
        (0, 3),  # 5 ordinal values
        (0, 3),  # 5 ordinal values
        (0, 3),  # 5 ordinal values
        (0, 3),  # 5 ordinal values
    ]
    dim = 4

    satisfaction_dict = {}
    calculated_dict={}

    # subprocess call
    def call_initializer(self, solution):
        # Specify the file path
        file_path = os.getcwd() + '/PR_best_crew.json'

        crew = np.array(solution)
        # Write the data to the JSON file
        with open(file_path, 'w') as file:
            json.dump(crew.tolist(), file)
        try:
            result = subprocess.run([interpreter_path, exploration_initializer,
                                     file_path, base_config_path, test_run_config_path], check=True, cwd=os.getcwd(),
                                    stdout=subprocess.PIPE, text=True, encoding='utf-8')
            result = float( result.stdout.splitlines()[-1] )  # The standard output of the subprocess
            # Now 'result' is properly defined within the try block
        except subprocess.CalledProcessError as e:
            print(f"Error running exploration script_path: {e}")
            raise RuntimeError("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))

        new_data = {
            'N1': solution[0],
            'N2': solution[1],
            'N3': solution[2],
            'N4': solution[3],
            'target': result  # Adjust the arguments as necessary
        }

        return new_data, result


    def get_random_satisfaction(self,crew):

        #print("tuple(crew)",tuple(crew))
        if tuple(crew) in self.satisfaction_dict:
            print("already exist")
            return self.satisfaction_dict[tuple(crew)]
        else:
            #print("not exist")
            # Generate a random satisfaction value between 0 and 100
            satisfaction = random.uniform(0, 750)
            # Store the satisfaction value in the dictionary for future use
            self.satisfaction_dict[tuple(crew)] = satisfaction
            return satisfaction

    def generate_all_crews(self):
        crews = []
        # Loop through all possible combinations of quantities for each feature level
        for q_low_low in range(4):
            for q_high_low in range(4):
                for q_low_high in range(4):
                    for q_high_high in range(4):
                        crew = [q_low_low, q_high_low, q_low_high, q_high_high]
                        crews.append(crew)
        return crews

    def calculate_max(self,X):
        # Fixed costs for each feature level
        q_low_low = X[0]
        q_high_low = X[1]
        q_low_high = X[2]
        q_high_high = X[3]
        cost_high_high = 70
        cost_high_low = 60
        cost_low_high = 50
        cost_low_low = 40



        # Calculate the total cost of the crew
        total_cost = q_low_low * cost_low_low + q_high_low * cost_high_low + q_low_high * cost_low_high + q_high_high * cost_high_high

        # Get the random satisfaction value for the crew
        satisfaction = self.satisfaction_dict[X]

        # Calculate the utility as Satisfaction - Cost
        utility = satisfaction - total_cost

        self.calculated_dict[X] = utility

        return utility

    def max_satisfaction(self, satisfaction_dict):
        max_pair = max(satisfaction_dict.items(), key=lambda item: item[1])
        print(max_pair)

    def generate_satisfaction_for_all_crews(self):
        crews = self.generate_all_crews()
        for crew in crews:
            self.get_random_satisfaction(crew)

    def __init__(
            self,
            # noise_std: Optional[float] = None,
            negate: bool = False,
            integer_indices: Optional[List[int]] = None,
    ) -> None:
        super().__init__(
            negate=negate, integer_indices=list(range(4))
        )

        self._setup(integer_indices=list(range(4)))
        self.discrete_values = BufferDict()
        for k, v in self._discrete_values.items():
            self.discrete_values[k] = torch.tensor(v, dtype=torch.float)
            # self.discrete_values[k] /= self.discrete_values[k].max()

        # Generate satisfaction values for all 1364 different crews
        self.generate_satisfaction_for_all_crews()
        for crew in self.satisfaction_dict:
            self.calculate_max(crew)
        self.max_satisfaction(self.calculated_dict)
        print(self.satisfaction_dict)
        result3 = self.satisfaction_dict[(1,0,0,0)]
        result2 = self.calculate_max((1,0,0,0))
        print("result2",result2)
        print("result3", result3)
    def evaluate_true(self, X: Tensor) -> Tensor:
        print("x is:", X)
        results = torch.tensor([])
        for element in X:
            print("element",element)
            result = self.get_value(element)
            #results = torch.cat((results, result.unsqueeze(0)), dim=0)
            results = torch.cat((results, result.unsqueeze(0)), dim=0)
            print("Result",results)

        return results

    def get_value(self, X_split):
        int_list = [int(x) for x in X_split.tolist()]
        print("get value: X_split",int_list)
        int_array = np.array(int_list)
        if np.all(int_array == 0):
            return torch.tensor(99999).to(torch.float64)
        new_data, result = self.call_initializer(int_array)


        result = float(result)
        result = torch.tensor(result).to(torch.float64)
        cost = self.cost_function(list(int_array))
        return (result + cost)

    def cost_function(self,q):
        # Fixed costs for each feature level

        cost_high_high = 70
        cost_high_low = 60
        cost_low_high = 50
        cost_low_low = 40

        if isinstance(q, list):
            total_cost = q[0] * cost_high_high + q[1] * cost_high_low + q[2] * cost_low_high + q[3] * cost_low_low

        else:
            # Calculate the total cost of the crew
            total_cost = q[:, 0] * cost_high_high + q[:, 1] * cost_high_low + q[:, 2] * cost_low_high + q[:,
                                                                                                        3] * cost_low_low

        return total_cost


